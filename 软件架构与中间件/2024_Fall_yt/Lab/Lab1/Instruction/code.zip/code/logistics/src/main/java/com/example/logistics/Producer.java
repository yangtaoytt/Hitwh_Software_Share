package com.example.logistics;

import com.example.logistics.factory.MessageFactory;
import com.example.logistics.interfaces.MessageQueue;

import java.util.Random;

public class Producer implements Runnable {
    private final MessageQueue queue;
    private final String name;
    public Producer(MessageQueue queue, String name) {
        this.queue = queue;
        this.name = name;
    }
    @Override
    public void run() {
        System.out.println("thread id" + Thread.currentThread().getId());
        int temp = new Random().nextInt(100);
        for (int i = temp; i < temp + 3; i++) {
            LogisticsInfo message =  MessageFactory.createMessage(Integer.toString(i),"未出库");;
            try {
                PackageState(message);
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    public void PackageState(LogisticsInfo message) throws InterruptedException {
        String[] statuses = {"未出库","已出库","已发货","已签收"};
        Random random = new Random();
        for (String status: statuses) {
            message.setStatus(status);
            queue.enqueue(message);
            System.out.println("生产者 " + name + " 将包裹信息放入消息队列中：" +"Package "+ message.getPackageId() + " Status "+message.getStatus());

        }
    }
}