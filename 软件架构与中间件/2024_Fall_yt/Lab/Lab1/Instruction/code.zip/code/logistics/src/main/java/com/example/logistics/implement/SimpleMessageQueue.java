package com.example.logistics.implement;




import com.example.logistics.LogisticsInfo;
import com.example.logistics.interfaces.Message;
import com.example.logistics.interfaces.MessageListener;
import com.example.logistics.interfaces.MessageQueue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * @description: 简单的消息队列类，实现了 MessageQueue 接口
 * @author: xyc
 * @date: 2023-04-25 16:18
 */
// 简单的消息队列类，实现了 MessageQueue 接口
public class SimpleMessageQueue implements MessageQueue {
    private  int capacity; // 队列容量
    private BlockingQueue<LogisticsInfo> messages;
    private List<MessageListener> listeners = new ArrayList<>();
    private  Object lock = new Object();


    public SimpleMessageQueue(int capacity) {
        this.capacity = capacity;
        this.messages = new LinkedBlockingQueue<>(capacity);
    }



    @Override
    public void enqueue(LogisticsInfo logisticsInfo) throws InterruptedException {
        messages.put(logisticsInfo); // 使用阻塞操作插入元素

    }

    @Override
    public LogisticsInfo dequeue() throws InterruptedException {
        LogisticsInfo logisticsInfo = messages.take(); // 使用阻塞操作移除元素
        return logisticsInfo;
    }

    @Override
    public void addListener(MessageListener listener) {
        listeners.add(listener);
    }

    @Override
    public void removeListener(MessageListener listener) {
        listeners.remove(listener);
    }


}