package com.example.logistics;

import com.example.logistics.interfaces.MessageListener;
import com.example.logistics.interfaces.MessageQueue;

public class Consumer implements Runnable {
    private final MessageQueue queue;
    private final String name;

    public Consumer(MessageQueue queue, String name) {
        this.queue = queue;
        this.name = name;
    }

    @Override
    public void run() {
        while (true) {
            try {
                LogisticsInfo message = queue.dequeue();
                System.out.println("消费者获" + name + "取到信息：Package ID: " + message.getPackageId() + " Status: " + message.getStatus());
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}