package org.example.implement;

import org.example.interfaces.Message;
import org.example.interfaces.MessageQueue;

public class RegisterListener {
    public void register(MessageQueue queue, int number){
        Message message = queue.dequeue();
        System.out.println("listener"+number+":"+message.getContent());
    }
}
