package com.hitwh.yt.service;

import com.hitwh.yt.entity.PackageStatusUpdateMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class WarehouseService {

    // Logger实例
    private static final Logger logger = LoggerFactory.getLogger(WarehouseService.class);

    @Autowired
    private RabbitTemplate rabbitTemplate;

    // 监听仓库队列，处理出库请求
    @RabbitListener(queues = "order_management_queue")
    public void handleOrderPlaced(PackageStatusUpdateMessage message) {
        // 打印收到订单创建请求的日志
        logger.info("\n***\n>>> WAREHOUSE SERVICE: Received Order - Package ID: {} | Status: {} | Timestamp: {}\n***",
                message.getPackageId(), message.getStatus(), message.getTimestamp());

        // 仓库处理完成后，将包裹发送到配送队列
        sendToDelivery(message.getPackageId());
    }

    // 发送配送请求到配送模块
    public void sendToDelivery(String packageId) {
        PackageStatusUpdateMessage message = new PackageStatusUpdateMessage(
                packageId,
                "warehouse_shipped",
                LocalDateTime.now()
        );

        // 打印仓库发送配送请求的日志
        logger.info("\n***\n>>> WAREHOUSE SERVICE: Sending to Delivery - Package ID: {}\n***", packageId);

        // 发送消息到配送队列
        rabbitTemplate.convertAndSend("logistics_exchange", "warehouse.shipped", message);
    }
}
