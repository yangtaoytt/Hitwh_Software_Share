package com.hitwh.yt.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
public class PackageStatusUpdateMessage implements Serializable {
    private String packageId;
    private String status;
    private LocalDateTime timestamp;

    // Constructor, Getters and Setters

    public PackageStatusUpdateMessage(String packageId, String status, LocalDateTime timestamp) {
        this.packageId = packageId;
        this.status = status;
        this.timestamp = timestamp;
    }

    public String getPackageId() {
        return packageId;
    }
    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}