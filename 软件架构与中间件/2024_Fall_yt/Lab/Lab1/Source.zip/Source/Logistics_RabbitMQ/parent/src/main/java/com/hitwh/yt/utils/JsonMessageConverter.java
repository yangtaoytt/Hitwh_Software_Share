package com.hitwh.yt.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hitwh.yt.entity.PackageStatusUpdateMessage;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.support.converter.MessageConversionException;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.amqp.core.Message;

public class JsonMessageConverter implements MessageConverter {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public Message toMessage(Object object, MessageProperties messageProperties) throws MessageConversionException {
        try {
            byte[] bytes = objectMapper.writeValueAsBytes(object);
            return new Message(bytes, messageProperties);
        } catch (Exception e) {
            throw new MessageConversionException("Failed to convert message", e);
        }
    }

    @Override
    public Object fromMessage(Message message) throws MessageConversionException {
        try {
            return objectMapper.readValue(message.getBody(), PackageStatusUpdateMessage.class);
        } catch (Exception e) {
            throw new MessageConversionException("Failed to deserialize message", e);
        }
    }
}

