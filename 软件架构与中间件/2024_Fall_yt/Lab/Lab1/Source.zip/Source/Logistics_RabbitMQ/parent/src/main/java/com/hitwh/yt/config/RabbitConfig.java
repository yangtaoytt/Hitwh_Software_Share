package com.hitwh.yt.config;


import org.springframework.amqp.core.*;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfig {

    @Bean
    public TopicExchange logisticsExchange() {
        return new TopicExchange("logistics_exchange");
    }

    @Bean
    public Queue orderManagementQueue() {
        return new Queue("order_management_queue", true);
    }

    @Bean
    public Queue warehouseQueue() {
        return new Queue("warehouse_queue", true);
    }

    @Bean
    public Queue deliveryQueue() {
        return new Queue("delivery_queue", true);
    }

    @Bean
    public Binding orderManagementBinding() {
        return BindingBuilder.bind(orderManagementQueue())
                .to(logisticsExchange())
                .with("order.placed");
    }

    @Bean
    public Binding warehouseBinding() {
        return BindingBuilder.bind(warehouseQueue())
                .to(logisticsExchange())
                .with("warehouse.shipped");
    }

    @Bean
    public Binding deliveryBinding() {
        return BindingBuilder.bind(deliveryQueue())
                .to(logisticsExchange())
                .with("delivery.delivered");
    }

}
