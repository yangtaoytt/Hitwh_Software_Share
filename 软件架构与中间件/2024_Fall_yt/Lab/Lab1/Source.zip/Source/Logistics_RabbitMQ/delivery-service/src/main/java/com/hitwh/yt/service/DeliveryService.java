package com.hitwh.yt.service;

import com.hitwh.yt.entity.PackageStatusUpdateMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class DeliveryService {

    // Logger实例
    private static final Logger logger = LoggerFactory.getLogger(DeliveryService.class);

    // 监听配送队列
    @RabbitListener(queues = "warehouse_queue")
    public void handleWarehouseShipped(PackageStatusUpdateMessage message) {
        // 打印收到仓库信息的日志
        logger.info("\n***\n>>> DELIVERY SERVICE: Received from warehouse - Package ID: {} | Status: {} | Timestamp: {}\n***",
                message.getPackageId(), message.getStatus(), message.getTimestamp());

        // 配送完成后，处理配送逻辑
        sendDeliveryCompleted(message.getPackageId());
    }

    // 发送配送完成通知
    public void sendDeliveryCompleted(String packageId) {
        // 打印配送完成的日志
        logger.info("\n***\n>>> DELIVERY SERVICE: Package Delivered - Package ID: {}\n***", packageId);
    }
}
