package com.hitwh.yt.service;

import com.hitwh.yt.entity.PackageStatusUpdateMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/order")
public class OrderCenter {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    private static final Logger logger = LoggerFactory.getLogger(OrderCenter.class);

    // 接收订单创建请求并发送到仓库
    @PostMapping("/create")
    public String createOrder(@RequestParam String packageId) {
        PackageStatusUpdateMessage message = new PackageStatusUpdateMessage(
                packageId,
                "order_placed",
                LocalDateTime.now()
        );

        // 打印日志，记录订单创建的过程
        logger.info("\n***\n>>> ORDER CREATED: Package ID: {} | Status: {} | Timestamp: {}\n***", packageId, "order_placed", LocalDateTime.now());

        // 发送消息到 RabbitMQ
        rabbitTemplate.convertAndSend("logistics_exchange", "order.placed", message);

        // 打印日志，记录消息发送到队列
        logger.info("\n***\n>>> MESSAGE SENT TO QUEUE: Package ID: {}\n***", packageId);

        return "Order placed and sent to warehouse: " + packageId;
    }
}