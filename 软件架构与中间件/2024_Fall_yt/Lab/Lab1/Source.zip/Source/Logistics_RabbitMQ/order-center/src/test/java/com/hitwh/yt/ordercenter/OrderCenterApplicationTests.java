package com.hitwh.yt.ordercenter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderCenterApplicationTests {

    @Test
    void contextLoads() {
    }

}
