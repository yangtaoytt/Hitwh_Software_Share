package cn.hitwh.yt.implement;

import cn.hitwh.yt.interfaces.ImprovedMessage;
import cn.hitwh.yt.interfaces.ImprovedMessageBuffer;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ImprovedSimpleMsgBuffer implements ImprovedMessageBuffer {
    private final List<ImprovedMessage> messages = new ArrayList<>();

    public ImprovedSimpleMsgBuffer(final List<ImprovedMessage> messages) {
        if (messages != null) {
            this.messages.addAll(messages);
        }
    }

    @Override
    public Optional<ImprovedMessage> getMsg() {
        if (messages.isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(messages.remove(0));
    }
}