package cn.hitwh.yt.interfaces;

import cn.hitwh.yt.implement.ImprovedSimpleMsgBuffer;

import java.util.Optional;
import java.util.function.Consumer;

public interface ImprovedMessageQueue {
    void enqueue(ImprovedMessage message);
    int addListener(Consumer<ImprovedMessageBuffer> callback);
    void removeListener(int hash);
}
