package cn.hitwh.yt;

import cn.hitwh.yt.factory.ImprovedMessageFactory;
import cn.hitwh.yt.interfaces.ImprovedMessage;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Example {
    public static void main(String[] args) {
        // 定义消息队列名称
        String queueName = "testQueue";

        // 创建生产者和消费者
        SimpleProducer producer = new SimpleProducer("Producer1", queueName);
        SimpleCustomer customer1 = new SimpleCustomer("Customer1", queueName);
        SimpleCustomer customer2 = new SimpleCustomer("Customer2", queueName);

        // 使用线程池运行生产者和消费者
        ExecutorService executorService = Executors.newCachedThreadPool();
        executorService.execute(producer);

        // 等待一段时间以接收消息
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // 打印消费者接收到的消息
        System.out.println("Customer1 received messages:");
        for (ImprovedMessage message : customer1.getMessages()) {
            System.out.println(message.getContent());
        }

        System.out.println("Customer2 received messages:");
        for (ImprovedMessage message : customer2.getMessages()) {
            System.out.println(message.getContent());
        }

        // 关闭线程池
        executorService.shutdown();

        // 显式退出程序并返回状态码 0
        System.exit(0);
    }

}
