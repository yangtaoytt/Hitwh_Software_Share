package org.example2.implement;


import org.example2.interfaces.Message;
import org.example2.interfaces.MessageListener;
import org.example2.interfaces.MessageQueue;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * @description: 简单的消息队列类，实现了 MessageQueue 接口
 * @author: xyc
 * @date: 2023-04-25 16:18
 */
// 简单的消息队列类，实现了 MessageQueue 接口
public class SimpleMessageQueue implements MessageQueue {
    private  int capacity; // 队列容量
    private BlockingQueue<Message> messages;
    private List<MessageListener> listeners = new CopyOnWriteArrayList<>();
    private  Object lock = new Object();

    public SimpleMessageQueue(int capacity) {
        this.capacity = capacity; // 使用 LinkedBlockingQueue 代替 List
        this.messages = new LinkedBlockingQueue<>(capacity);
    }
    @Override
    public void enqueue(Message message) throws InterruptedException {
        messages.put(message); // 使用阻塞操作插入元素
        notifyListeners();
    }
    @Override
    public Message dequeue() throws InterruptedException {
        Message message = messages.take(); // 使用阻塞操作移除元素
        return message;
    }
    @Override
    public void addListener(MessageListener listener) {
        listeners.add(listener);
    }
    @Override
    public void removeListener(MessageListener listener) {
        listeners.remove(listener);
    }
    private void notifyListeners() throws InterruptedException {
        for (MessageListener listener : listeners) {
            if (listener != null) {
                listener.onMessageChanged(this);
            }
        }
    }

}