import org.example2.Consumer;
import org.example2.Producer;
import org.example2.factory.MessageFactory;
import org.example2.interfaces.Message;
import org.example2.interfaces.MessageQueue;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ProducerConsumerTests {

    // Consumer类测试
    @Nested
    public class ConsumerTest {

        @Test
        void testConsumerReceivesMessages() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue(10);
            StringBuilder result = new StringBuilder();

            // 启动一个消费者线程
            Consumer consumer = new Consumer(queue, "Consumer 1", result);
            Thread consumerThread = new Thread(consumer);
            consumerThread.start();

            // 向队列添加消息
            Message message = MessageFactory.createMessage("Test Message");
            queue.enqueue(message);

            // 等待消费者处理消息
            Thread.sleep(1000);

            assertTrue(result.toString().contains("Test Message"), "Consumer should receive the correct message.");
        }

        @Test
        void testConsumerMultipleMessages() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue(10);
            StringBuilder result = new StringBuilder();

            // 启动一个消费者线程
            Consumer consumer = new Consumer(queue, "Consumer 1", result);
            Thread consumerThread = new Thread(consumer);
            consumerThread.start();

            // 向队列添加多个消息
            for (int i = 0; i < 5; i++) {
                Message message = MessageFactory.createMessage("Message " + i);
                queue.enqueue(message);
            }

            // 等待消费者处理完消息
            Thread.sleep(1000);

            // 验证消费者是否处理了所有消息
            for (int i = 0; i < 5; i++) {
                assertTrue(result.toString().contains("Message " + i), "Consumer should receive all messages.");
            }
        }

        @Test
        void testConsumerWithTimeout() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue(10);

            // 启动一个消费者线程
            Consumer consumer = new Consumer(queue, "Consumer 1");
            Thread consumerThread = new Thread(consumer);
            consumerThread.start();

            // 确保消费者在一定时间内能处理消息
            Thread.sleep(1000);

            // 确保消费者线程仍然在运行
            assertTrue(consumerThread.isAlive(), "Consumer thread should be running.");
        }
    }

    // Producer类测试
    @Nested
    public class ProducerTest {

        @Test
        void testProducerSendsMessages() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue(10);

            // 启动一个生产者线程
            Producer producer = new Producer(queue, "Producer 1");
            Thread producerThread = new Thread(producer);
            producerThread.start();

            // 等待生产者发送消息
            Thread.sleep(1000);

            // 验证队列中有消息
            assertNotNull(queue.dequeue(), "Queue should have received a message from the producer.");
        }

        @Test
        void testProducerMultipleMessages() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue(10);

            // 启动一个生产者线程
            Producer producer = new Producer(queue, "Producer 1");
            Thread producerThread = new Thread(producer);
            producerThread.start();

            // 等待生产者发送多个消息
            Thread.sleep(1500);

            // 确保队列中有多个消息
            for (int i = 0; i < 5; i++) {
                assertNotNull(queue.dequeue(), "Queue should have received multiple messages from the producer.");
            }
        }

        @Test
        void testProducerAndConsumerIntegration() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue(10);
            StringBuilder result = new StringBuilder();

            // 启动一个生产者和一个消费者线程
            Producer producer = new Producer(queue, "Producer 1");
            Consumer consumer = new Consumer(queue, "Consumer 1", result);

            Thread producerThread = new Thread(producer);
            Thread consumerThread = new Thread(consumer);

            producerThread.start();
            consumerThread.start();

            // 等待生产者和消费者完成操作
            Thread.sleep(3000);

            // 确保消费者接收到消息
            assertTrue(result.toString().contains("Message"), "Consumer should receive messages produced by producer.");
        }
    }

    // Producer-Consumer 并发测试
    @Nested
    public class ProducerConsumerConcurrencyTest {

        @Test
        void testMultipleProducersAndConsumers() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue(10);
            StringBuilder result = new StringBuilder();

            // 启动多个生产者和消费者线程
            Producer producer1 = new Producer(queue, "Producer 1");
            Producer producer2 = new Producer(queue, "Producer 2");
            Consumer consumer1 = new Consumer(queue, "Consumer 1", result);
            Consumer consumer2 = new Consumer(queue, "Consumer 2", result);

            Thread producerThread1 = new Thread(producer1);
            Thread producerThread2 = new Thread(producer2);
            Thread consumerThread1 = new Thread(consumer1);
            Thread consumerThread2 = new Thread(consumer2);

            producerThread1.start();
            producerThread2.start();
            consumerThread1.start();
            consumerThread2.start();

            // 等待所有线程执行完
            Thread.sleep(5000);

            // 验证消费者是否接收到生产者发送的消息
            assertTrue(result.length() > 0, "Consumers should receive messages from multiple producers.");
        }
    }
}
