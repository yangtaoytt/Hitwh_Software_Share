package org.example2.interfaces;

public interface MessageListener {
    void onMessageChanged(MessageQueue queue) throws InterruptedException;
}