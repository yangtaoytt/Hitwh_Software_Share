package org.example1;

import org.example1.factory.MessageFactory;
import org.example1.interfaces.Message;
import org.example1.interfaces.MessageCenter;
import org.example1.interfaces.MessageListener;
import org.example1.interfaces.MessageQueue;

public class Example {
    public static void main(String[] args) throws InterruptedException {
        // 创建消息中心
        MessageCenter messageCenter = MessageFactory.createMessageCenter();

        // 创建消息队列
        MessageQueue queue1 = MessageFactory.createMessageQueue();
        MessageQueue queue2 = MessageFactory.createMessageQueue();

        // 注册消息队列到消息中心
        messageCenter.registerQueue(queue1);
        messageCenter.registerQueue(queue2);

        // 为消息队列添加监听器
        queue1.addListener(queue -> {
            Message message = queue.dequeue();
            if (message != null) {
                System.out.println("Queue1 received message: " + message.getContent());
            }
        });

        queue2.addListener(queue -> {
            Message message = queue.dequeue();
            if (message != null) {
                System.out.println("Queue2 received message: " + message.getContent());
            }
        });

        // 广播消息
        System.out.println("Broadcasting messages...");
        for (int i = 1; i <= 5; i++) {
            Message message = MessageFactory.createMessage("Message " + i);
            messageCenter.broadcast(message);
        }

        // 延迟一段时间以确保消息被处理
        Thread.sleep(1000);

        // 取消注册队列
        messageCenter.unregisterQueue(queue1);
        messageCenter.unregisterQueue(queue2);

        System.out.println("Example completed.");
    }
}
