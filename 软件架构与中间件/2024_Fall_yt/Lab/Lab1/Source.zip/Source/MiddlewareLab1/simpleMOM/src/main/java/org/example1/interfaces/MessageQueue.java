package org.example1.interfaces;

public interface MessageQueue {
    void enqueue(Message message) throws InterruptedException;
    Message dequeue();
    void addListener(MessageListener listener);
    void removeListener(MessageListener listener);
}
