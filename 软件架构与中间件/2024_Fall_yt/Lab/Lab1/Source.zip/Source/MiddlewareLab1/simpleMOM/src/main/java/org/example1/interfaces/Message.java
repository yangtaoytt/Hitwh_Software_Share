package org.example1.interfaces;

// 消息接口，表示一个消息
public interface Message {
    String getContent();
}
