package org.example1.interfaces;

public interface MessageListener {
    void onMessageChanged(MessageQueue queue);
}