package cn.hitwh.yt.implement;

import cn.hitwh.yt.factory.ImprovedMessageFactory;
import cn.hitwh.yt.interfaces.ImprovedMessage;
import cn.hitwh.yt.interfaces.ImprovedMessageBuffer;
import cn.hitwh.yt.interfaces.ImprovedMessageCenter;
import cn.hitwh.yt.interfaces.ImprovedMessageQueue;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.util.function.Consumer;

public class ImprovedSimpleMsgCenter implements ImprovedMessageCenter {
    private ImprovedSimpleMsgCenter() {}

    private static class SingletonHelper {
        private static final ImprovedSimpleMsgCenter INSTANCE = new ImprovedSimpleMsgCenter();
    }

    public static ImprovedSimpleMsgCenter getInstance() {
        return SingletonHelper.INSTANCE;
    }

    // 使用 ConcurrentHashMap 替代 Hashtable，支持高并发
    private Map<String, ImprovedMessageQueue> queues = new ConcurrentHashMap<>();

    @Override
    public int addListener(String msgQueueName, Consumer<ImprovedMessageBuffer> listener) {
        if (msgQueueName == null || listener == null) {
            throw new IllegalArgumentException("msgType and listener cannot be null");
        }
        // 避免重复创建队列
        queues.computeIfAbsent(msgQueueName, key -> ImprovedMessageFactory.createMsgQueue());
        return queues.get(msgQueueName).addListener(listener);
    }

    @Override
    public void removeListener(String msgQueueName, int identifier) {
        if (msgQueueName == null) {
            return;
        }
        ImprovedMessageQueue queue = queues.get(msgQueueName);
        if (queue != null) {
            queue.removeListener(identifier);
        }
    }

    @Override
    public void sendMessage(String msgQueueName, ImprovedMessage msg) {
        if (msgQueueName == null || msg == null) {
            return;
        }
        ImprovedMessageQueue queue = queues.get(msgQueueName);
        if (queue != null) {
            queue.enqueue(msg);
        }
    }
}