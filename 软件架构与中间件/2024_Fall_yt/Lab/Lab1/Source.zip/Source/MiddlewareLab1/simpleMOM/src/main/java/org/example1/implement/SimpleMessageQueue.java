package org.example1.implement;


import org.example1.interfaces.Message;
import org.example1.interfaces.MessageListener;
import org.example1.interfaces.MessageQueue;

import java.util.ArrayList;
import java.util.List;

/**
 * @description: 简单的消息队列类，实现了 MessageQueue 接口
 * @author: xyc
 * @date: 2023-04-25 16:18
 */
// 简单的消息队列类，实现了 MessageQueue 接口
public class SimpleMessageQueue implements MessageQueue {
    private List<Message> messages = new ArrayList<>();
    private List<MessageListener> listeners = new ArrayList<>();
    @Override
    public void enqueue(Message message) {
        messages.add(message);
        notifyListeners();
    }
    @Override
    public Message dequeue() {
        if (messages.isEmpty()) {
            return null;
        }
        Message message = messages.remove(0);
        return message;
    }
    @Override
    public void addListener(MessageListener listener) {
        if(listener != null)
            listeners.add(listener);
    }
    @Override
    public void removeListener(MessageListener listener) {
        if(listener != null)
            listeners.remove(listener);
    }
    private void notifyListeners()  {
        for (MessageListener listener : listeners) {
            if (listener != null) {
                listener.onMessageChanged(this);
            }
        }
    }
}