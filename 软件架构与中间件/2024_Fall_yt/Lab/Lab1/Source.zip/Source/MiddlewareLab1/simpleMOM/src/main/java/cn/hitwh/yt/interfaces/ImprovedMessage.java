package cn.hitwh.yt.interfaces;

public interface ImprovedMessage {
    Object getContent();
}
