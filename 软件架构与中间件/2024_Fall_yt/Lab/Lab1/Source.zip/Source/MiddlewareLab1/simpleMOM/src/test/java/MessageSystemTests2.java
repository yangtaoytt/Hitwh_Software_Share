import org.example2.factory.MessageFactory;
import org.example2.interfaces.Message;
import org.example2.interfaces.MessageCenter;
import org.example2.interfaces.MessageListener;
import org.example2.interfaces.MessageQueue;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class MessageSystemTests2 {

    // Message接口测试
    @Nested
    public class MessageTest {

        @Test
        void testGetContent_ValidMessage_ReturnsCorrectContent() {
            Message message = MessageFactory.createMessage("Hello");
            assertEquals("Hello", message.getContent(), "Message content should be 'Hello'");
        }

        @Test
        void testGetContent_EmptyMessage_ReturnsEmptyString() {
            Message message = MessageFactory.createMessage("");
            assertEquals("", message.getContent(), "Message content should be an empty string");
        }
    }

    // MessageQueue接口测试
    @Nested
    public class MessageQueueTest {

        @Test
        void testEnqueue_ValidMessage_MessageIsEnqueued() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue(10);  // 传递容量
            queue.enqueue(MessageFactory.createMessage("Test"));
            assertNotNull(queue.dequeue(), "Message should be enqueued and dequeued correctly");
        }

        @Test
        void testDequeue_ValidMessage_MessageIsDequeued() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue(10);  // 传递容量
            Message message = MessageFactory.createMessage("Test");
            queue.enqueue(message);
            assertEquals("Test", queue.dequeue().getContent(), "Dequeued message content should be 'Test'");
        }

        @Test
        void testDequeue_EmptyQueue_BlockAndTimeout() throws InterruptedException {
            // 创建一个队列，容量为 10
            MessageQueue queue = MessageFactory.createMessageQueue(10);

            // 启动一个线程执行 dequeue 操作
            Thread dequeueThread = new Thread(() -> {
                try {
                    // 阻塞调用 dequeue，直到队列有消息
                    Message message = queue.dequeue();
                    assertNull(message, "Dequeue should return null when queue is empty after timeout");
                } catch (InterruptedException e) {
                    // 确保如果线程被中断时捕获到异常并且测试成功
                }
            });

            // 启动线程
            dequeueThread.start();

            // 使用 assertTimeoutPreemptively 来模拟超时阻塞并进行中断
            assertTimeoutPreemptively(java.time.Duration.ofMillis(500), () -> {
                // 等待线程在 100 毫秒后开始执行
                Thread.sleep(100);
                dequeueThread.interrupt(); // 中断线程
            });

            // 等待线程执行完成
            dequeueThread.join();
        }
        @Test
        void testAddListener_ValidListener_ListenerIsAdded() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue(10);  // 传递容量
            StringBuilder result = new StringBuilder();
            MessageListener listener = q -> result.append(q.dequeue().getContent());
            queue.addListener(listener);

            // 向队列中添加一个消息并触发监听器
            queue.enqueue(MessageFactory.createMessage("Test"));
            Thread.sleep(100); // 等待消息处理

            assertTrue(result.toString().contains("Test"), "Listener should process the enqueued message");
        }

        @Test
        void testRemoveListener_ValidListener_ListenerIsRemoved() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue(10);  // 传递容量
            StringBuilder result = new StringBuilder();
            MessageListener listener = q -> result.append(q.dequeue().getContent());
            queue.addListener(listener);
            queue.removeListener(listener);

            // 向队列中添加一个消息
            queue.enqueue(MessageFactory.createMessage("Test"));
            Thread.sleep(100); // 等待消息处理

            assertEquals("", result.toString(), "Listener should not process the message after being removed");
        }
    }

    // MessageCenter接口测试
    @Nested
    public class MessageCenterTest {

        @Test
        void testRegisterQueue_ValidQueue_QueueIsRegistered() {
            MessageCenter center = MessageFactory.createMessageCenter();
            MessageQueue queue = MessageFactory.createMessageQueue(10);  // 传递容量
            center.registerQueue(queue);
            Message message = MessageFactory.createMessage("Test");
            assertDoesNotThrow(() -> center.broadcast(message, queue), "Broadcasting should not throw an exception");
        }

        @Test
        void testUnregisterQueue_RegisteredQueue_QueueIsUnregistered() {
            MessageCenter center = MessageFactory.createMessageCenter();
            MessageQueue queue = MessageFactory.createMessageQueue(10);  // 传递容量
            center.registerQueue(queue);
            center.unregisterQueue(queue);
            Message message = MessageFactory.createMessage("Test");
            assertDoesNotThrow(() -> center.broadcast(message, queue), "Broadcasting should not throw an exception after queue is unregistered");
        }

        @Test
        void testBroadcast_ValidMessage_OnlyOneQueueReceivesMessage() throws InterruptedException {
            MessageCenter center = MessageFactory.createMessageCenter();
            MessageQueue queue1 = MessageFactory.createMessageQueue(10);  // 传递容量
            MessageQueue queue2 = MessageFactory.createMessageQueue(10);  // 传递容量
            center.registerQueue(queue1);
            center.registerQueue(queue2);

            StringBuilder result = new StringBuilder();
            MessageListener listener1 = q -> result.append("Queue1: " + q.dequeue().getContent() + "; ");
            MessageListener listener2 = q -> result.append("Queue2: " + q.dequeue().getContent() + "; ");
            queue1.addListener(listener1);
            queue2.addListener(listener2);

            // 将消息发送到队列1
            Message message = MessageFactory.createMessage("Hello");
            center.broadcast(message, queue1);  // 只向队列1广播消息

            // 等待消息处理
            Thread.sleep(100);

            // 确保只有队列1处理了消息
            assertTrue(result.toString().contains("Queue1: Hello;"));
            assertFalse(result.toString().contains("Queue2: Hello;"), "Queue2 should not receive the message");
        }

        @Test
        void testBroadcast_EmptyQueue_NoMessagesReceived() throws InterruptedException {
            MessageCenter center = MessageFactory.createMessageCenter();
            Message message = MessageFactory.createMessage("Hello");
            MessageQueue queue = MessageFactory.createMessageQueue(10);  // 传递容量
            assertDoesNotThrow(() -> center.broadcast(message, queue), "Broadcasting should not throw an exception when no queue is registered");
        }
    }

    // MessageListener接口测试
    @Nested
    public class MessageListenerTest {

        @Test
        void testOnMessageChanged_ValidMessage_ListenerReceivesMessage() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue(10);  // 传递容量
            StringBuilder result = new StringBuilder();
            MessageListener listener = q -> result.append(q.dequeue().getContent());
            queue.addListener(listener);
            queue.enqueue(MessageFactory.createMessage("Test Message"));

            // 等待消息处理
            Thread.sleep(100);

            assertTrue(result.toString().contains("Test Message"));
        }

        @Test
        void testOnMessageChanged_EmptyQueue_NoMessageReceived() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue(10);  // 传递容量
            StringBuilder result = new StringBuilder();
            MessageListener listener = q -> result.append(q.dequeue().getContent());
            queue.addListener(listener);

            // 等待消息处理
            Thread.sleep(100);

            assertEquals("", result.toString(), "Listener should not receive any message when queue is empty");
        }

    }

    // MessageFactory测试
    @Nested
    public class MessageFactoryTest {

        @Test
        void testCreateMessage_ValidContent_MessageIsCreated() {
            Message message = MessageFactory.createMessage("Test Message");
            assertEquals("Test Message", message.getContent(), "Message content should be 'Test Message'");
        }

        @Test
        void testCreateMessageQueue_ValidQueue_MessageQueueIsCreated() {
            MessageQueue queue = MessageFactory.createMessageQueue(10);  // 传递容量
            assertNotNull(queue, "MessageQueue should be created");
        }

        @Test
        void testCreateMessageCenter_ValidCenter_MessageCenterIsCreated() {
            MessageCenter center = MessageFactory.createMessageCenter();
            assertNotNull(center, "MessageCenter should be created");
        }
    }

    // Example类测试
    @Nested
    public class ExampleTest {

        @Test
        void testExample_CompleteMessageFlow_MessageIsSentAndReceived() throws InterruptedException {
            MessageCenter center = MessageFactory.createMessageCenter();
            MessageQueue queue1 = MessageFactory.createMessageQueue(10);  // 传递容量
            MessageQueue queue2 = MessageFactory.createMessageQueue(10);  // 传递容量
            center.registerQueue(queue1);
            center.registerQueue(queue2);

            StringBuilder result = new StringBuilder();
            MessageListener listener1 = q -> result.append("Queue1: " + q.dequeue().getContent() + "; ");
            MessageListener listener2 = q -> result.append("Queue2: " + q.dequeue().getContent() + "; ");
            queue1.addListener(listener1);
            queue2.addListener(listener2);

            Message message = MessageFactory.createMessage("Hello");
            center.broadcast(message, queue1);  // 只向队列1广播消息

            // 等待消息处理
            Thread.sleep(100);

            assertTrue(result.toString().contains("Queue1: Hello;"));
            assertFalse(result.toString().contains("Queue2: Hello;"), "Queue2 should not receive the message");

            center.unregisterQueue(queue1);
            center.unregisterQueue(queue2);
            queue1.removeListener(listener1);
            queue2.removeListener(listener2);
        }
    }
}
