package cn.hitwh.yt.implement;

import cn.hitwh.yt.interfaces.ImprovedMessage;

public class IntMessage implements ImprovedMessage {
    private Integer value;

    public IntMessage(Integer value) {
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    @Override
    public Object getContent() {
        return value;
    }
}

