package org.example1.factory;


import org.example1.implement.SimpleMessage;
import org.example1.implement.SimpleMessageCenter;
import org.example1.implement.SimpleMessageQueue;
import org.example1.interfaces.Message;
import org.example1.interfaces.MessageCenter;
import org.example1.interfaces.MessageQueue;

/**
 * @description: 负责创建消息、消息队列和消息中心的实例。
 * @author: xyc
 * @date: 2023-04-25 16:07
 */
public class MessageFactory {
    // 私有化构造函数，禁止外部创建对象
    private MessageFactory() {}

    // 创建一个Message对象
    public static Message createMessage(String content) {
        return new SimpleMessage(content);
    }

    // 创建一个MessageQueue对象
    public static MessageQueue createMessageQueue() {
        return new SimpleMessageQueue();
    }

    // 创建一个MessageCenter对象
    public static MessageCenter createMessageCenter() {
        return SimpleMessageCenter.getInstance();
    }
}