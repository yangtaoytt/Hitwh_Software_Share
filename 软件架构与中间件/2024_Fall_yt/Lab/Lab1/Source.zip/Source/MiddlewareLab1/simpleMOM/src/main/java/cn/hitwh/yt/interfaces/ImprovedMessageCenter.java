package cn.hitwh.yt.interfaces;


import java.util.function.Consumer;

public interface ImprovedMessageCenter {
    int addListener(String msgQueueName, Consumer<ImprovedMessageBuffer> listener);
    void removeListener(String msgQueueName, int identifier);
    void sendMessage(String msgQueueName, ImprovedMessage msg);
}
