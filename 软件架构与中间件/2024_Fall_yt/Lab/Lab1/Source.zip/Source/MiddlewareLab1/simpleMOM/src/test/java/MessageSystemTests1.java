import org.example1.factory.MessageFactory;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Nested;
import static org.junit.jupiter.api.Assertions.*;
import org.example1.interfaces.*;

public class MessageSystemTests1 {

    // Message接口测试
    @Nested
    public class MessageTest {

        @Test
        void testGetContent_ValidMessage_ReturnsCorrectContent() {
            Message message = MessageFactory.createMessage("Hello");
            assertEquals("Hello", message.getContent(), "Message content should be 'Hello'");
        }

        @Test
        void testGetContent_EmptyMessage_ReturnsEmptyString() {
            Message message = MessageFactory.createMessage("");
            assertEquals("", message.getContent(), "Message content should be an empty string");
        }
    }

    // MessageQueue接口测试
    @Nested
    public class MessageQueueTest {

        @Test
        void testEnqueue_ValidMessage_MessageIsEnqueued() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue();
            queue.enqueue(MessageFactory.createMessage("Test"));
            assertNotNull(queue.dequeue(), "Message should be enqueued and dequeued correctly");
        }

        @Test
        void testDequeue_ValidMessage_MessageIsDequeued() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue();
            Message message = MessageFactory.createMessage("Test");
            queue.enqueue(message);
            assertEquals("Test", queue.dequeue().getContent(), "Dequeued message content should be 'Test'");
        }

        @Test
        void testDequeue_EmptyQueue_ReturnsNull() {
            MessageQueue queue = MessageFactory.createMessageQueue();
            assertNull(queue.dequeue(), "Dequeue should return null when queue is empty");
        }

        @Test
        void testAddListener_ValidListener_ListenerIsAdded() {
            MessageQueue queue = MessageFactory.createMessageQueue();
            StringBuilder result = new StringBuilder();
            MessageListener listener = q -> result.append(q.dequeue().getContent());
            queue.addListener(listener);
            assertTrue(queue.dequeue() == null, "Listener should be added successfully");
        }

        @Test
        void testRemoveListener_ValidListener_ListenerIsRemoved() {
            MessageQueue queue = MessageFactory.createMessageQueue();
            StringBuilder result = new StringBuilder();
            MessageListener listener = q -> result.append(q.dequeue().getContent());
            queue.addListener(listener);
            queue.removeListener(listener);
            assertDoesNotThrow(() -> queue.enqueue(MessageFactory.createMessage("Test")));
            assertEquals("", result.toString(), "Listener should be removed successfully");
        }
    }

    // MessageCenter接口测试
    @Nested
    public class MessageCenterTest {

        @Test
        void testRegisterQueue_ValidQueue_QueueIsRegistered() {
            MessageCenter center = MessageFactory.createMessageCenter();
            MessageQueue queue = MessageFactory.createMessageQueue();
            center.registerQueue(queue);
            Message message = MessageFactory.createMessage("Test");
            assertDoesNotThrow(() -> center.broadcast(message), "Broadcasting should not throw an exception");
        }

        @Test
        void testUnregisterQueue_RegisteredQueue_QueueIsUnregistered() {
            MessageCenter center = MessageFactory.createMessageCenter();
            MessageQueue queue = MessageFactory.createMessageQueue();
            center.registerQueue(queue);
            center.unregisterQueue(queue);
            Message message = MessageFactory.createMessage("Test");
            assertDoesNotThrow(() -> center.broadcast(message), "Broadcasting should not throw an exception after queue is unregistered");
        }

        @Test
        void testBroadcast_ValidMessage_AllQueuesReceiveMessage() throws InterruptedException {
            MessageCenter center = MessageFactory.createMessageCenter();
            MessageQueue queue1 = MessageFactory.createMessageQueue();
            MessageQueue queue2 = MessageFactory.createMessageQueue();
            center.registerQueue(queue1);
            center.registerQueue(queue2);

            StringBuilder result = new StringBuilder();
            MessageListener listener1 = queue -> result.append("Queue1: " + queue.dequeue().getContent() + "; ");
            MessageListener listener2 = queue -> result.append("Queue2: " + queue.dequeue().getContent() + "; ");
            queue1.addListener(listener1);
            queue2.addListener(listener2);

            Message message = MessageFactory.createMessage("Hello");
            center.broadcast(message);

            assertTrue(result.toString().contains("Queue1: Hello;"));
            assertTrue(result.toString().contains("Queue2: Hello;"));
        }

        @Test
        void testBroadcast_EmptyQueue_NoMessagesReceived() throws InterruptedException {
            MessageCenter center = MessageFactory.createMessageCenter();
            Message message = MessageFactory.createMessage("Hello");
            assertDoesNotThrow(() -> center.broadcast(message), "Broadcasting should not throw an exception when no queue is registered");
        }
    }

    // MessageListener接口测试
    @Nested
    public class MessageListenerTest {

        @Test
        void testOnMessageChanged_ValidMessage_ListenerReceivesMessage() throws InterruptedException {
            MessageQueue queue = MessageFactory.createMessageQueue();
            StringBuilder result = new StringBuilder();
            MessageListener listener = q -> result.append(q.dequeue().getContent());
            queue.addListener(listener);
            queue.enqueue(MessageFactory.createMessage("Test Message"));
            assertTrue(result.toString().contains("Test Message"));
        }

        @Test
        void testOnMessageChanged_EmptyQueue_NoMessageReceived() {
            MessageQueue queue = MessageFactory.createMessageQueue();
            StringBuilder result = new StringBuilder();
            MessageListener listener = q -> result.append(q.dequeue().getContent());
            queue.addListener(listener);
            assertEquals("", result.toString(), "Listener should not receive any message when queue is empty");
        }

    }

    // MessageFactory测试
    @Nested
    public class MessageFactoryTest {

        @Test
        void testCreateMessage_ValidContent_MessageIsCreated() {
            Message message = MessageFactory.createMessage("Test Message");
            assertEquals("Test Message", message.getContent(), "Message content should be 'Test Message'");
        }

        @Test
        void testCreateMessageQueue_ValidQueue_MessageQueueIsCreated() {
            MessageQueue queue = MessageFactory.createMessageQueue();
            assertNotNull(queue, "MessageQueue should be created");
        }

        @Test
        void testCreateMessageCenter_ValidCenter_MessageCenterIsCreated() {
            MessageCenter center = MessageFactory.createMessageCenter();
            assertNotNull(center, "MessageCenter should be created");
        }
    }

    // Example类测试
    @Nested
    public class ExampleTest {

        @Test
        void testExample_CompleteMessageFlow_MessageIsSentAndReceived() throws InterruptedException {
            MessageCenter center = MessageFactory.createMessageCenter();
            MessageQueue queue1 = MessageFactory.createMessageQueue();
            MessageQueue queue2 = MessageFactory.createMessageQueue();
            center.registerQueue(queue1);
            center.registerQueue(queue2);

            StringBuilder result = new StringBuilder();
            MessageListener listener1 = q -> result.append("Queue1: " + q.dequeue().getContent() + "; ");
            MessageListener listener2 = q -> result.append("Queue2: " + q.dequeue().getContent() + "; ");
            queue1.addListener(listener1);
            queue2.addListener(listener2);

            Message message = MessageFactory.createMessage("Hello");
            center.broadcast(message);

            assertTrue(result.toString().contains("Queue1: Hello;"));
            assertTrue(result.toString().contains("Queue2: Hello;"));

            center.unregisterQueue(queue1);
            center.unregisterQueue(queue2);
            queue1.removeListener(listener1);
            queue2.removeListener(listener2);
        }
    }
}
