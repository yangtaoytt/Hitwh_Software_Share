package cn.hitwh.yt.factory;

import cn.hitwh.yt.implement.ImprovedSimpleMsgBuffer;
import cn.hitwh.yt.implement.ImprovedSimpleMsgCenter;
import cn.hitwh.yt.implement.ImprovedSimpleMsgQueue;
import cn.hitwh.yt.implement.IntMessage;
import cn.hitwh.yt.interfaces.ImprovedMessage;
import cn.hitwh.yt.interfaces.ImprovedMessageBuffer;
import cn.hitwh.yt.interfaces.ImprovedMessageCenter;
import cn.hitwh.yt.interfaces.ImprovedMessageQueue;

import java.util.List;

public class ImprovedMessageFactory {
    private ImprovedMessageFactory() {}

    public enum MessageType {
        intMessage
    }
    public static ImprovedMessage createMsg(MessageType type, Object... params) {
        switch (type) {
            case intMessage:
                return new IntMessage((Integer) params[0]);
            // 可扩展其他消息类型
            default:
                throw new IllegalArgumentException("Unsupported message type: " + type);
        }
    }

    public static ImprovedMessageQueue createMsgQueue() {
        return new ImprovedSimpleMsgQueue();
    }

    public static ImprovedMessageCenter createMsgCenter() {
        return ImprovedSimpleMsgCenter.getInstance();
    }

    public static ImprovedMessageBuffer createMsgBuffer(List<ImprovedMessage> messageList) {
        return new ImprovedSimpleMsgBuffer(messageList);
    }
}