import cn.hitwh.yt.SimpleCustomer;
import cn.hitwh.yt.SimpleProducer;
import cn.hitwh.yt.implement.IntMessage;
import cn.hitwh.yt.interfaces.ImprovedMessage;
import cn.hitwh.yt.interfaces.ImprovedMessageCenter;
import cn.hitwh.yt.factory.ImprovedMessageFactory;
import org.junit.jupiter.api.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;

public class ProducerConsumerTest {

    private static ImprovedMessageCenter messageCenter;
    private static final String QUEUE_NAME = "testQueue";
    
    private SimpleProducer producer;
    private SimpleCustomer customer;

    @BeforeAll
    public static void setupAll() {
        messageCenter = ImprovedMessageFactory.createMsgCenter();
    }

    @BeforeEach
    public void setup() {
        customer = new SimpleCustomer("SimpleCustomer", QUEUE_NAME); // customer listens to the same queue
        producer = new SimpleProducer("SimpleProducer", QUEUE_NAME); // producer writes to the same queue
    }

    @Test
    public void testProducerConsumerIntegration() throws InterruptedException {
        // Run the producer in a separate thread
        Thread producerThread = new Thread(producer);
        producerThread.start();

        // Wait for some time to allow messages to be processed
        producerThread.join();

        // Ensure consumer received all messages
        List<ImprovedMessage> receivedMessages = customer.getMessages();
        assertEquals(10, receivedMessages.size(), "Consumer should receive 10 messages.");
        
        // Check if the messages are in the correct order (0, 1, 2, ..., 9)
        for (int i = 0; i < receivedMessages.size(); i++) {
            ImprovedMessage msg = receivedMessages.get(i);
            assertTrue(msg instanceof IntMessage, "Received message should be of type IntMessage.");
            assertEquals(i, msg.getContent(), "Message content should match the sent value.");
        }
    }

    @Test
    public void testProducerConsumerConcurrency() throws InterruptedException, ExecutionException {
        // Run multiple producers in parallel to simulate concurrency
        ExecutorService executorService = Executors.newFixedThreadPool(2);

        // Run multiple producer tasks
        List<Callable<Void>> tasks = new ArrayList<>();
        tasks.add(() -> { producer.run(); return null; });
        tasks.add(() -> { producer.run(); return null; });

        List<Future<Void>> futures = executorService.invokeAll(tasks);
        
        // Wait for all producers to finish
        for (Future<Void> future : futures) {
            future.get();
        }

        // Ensure the consumer has received all messages (20 messages, 10 from each producer)
        List<ImprovedMessage> receivedMessages = customer.getMessages();
        assertEquals(20, receivedMessages.size(), "Consumer should receive 20 messages.");

        for (int i = 0; i < receivedMessages.size(); i++) {
            ImprovedMessage msg = receivedMessages.get(i);
            assertTrue(msg instanceof IntMessage, "Received message should be of type IntMessage.");
        }
        
        executorService.shutdown();
    }

    @Test
    public void testMessageOrder() throws InterruptedException {
        // Start the producer in a separate thread
        Thread producerThread = new Thread(producer);
        producerThread.start();
        producerThread.join(); // Wait until the producer finishes

        // Ensure that the consumer received messages in the correct order
        List<ImprovedMessage> receivedMessages = customer.getMessages();
        for (int i = 0; i < receivedMessages.size(); i++) {
            ImprovedMessage receivedMessage = receivedMessages.get(i);
            assertTrue(receivedMessage instanceof IntMessage, "Received message should be of type IntMessage.");
            assertEquals(i, receivedMessage.getContent(), 
                "The received message content does not match the expected value.");
        }
    }

    @Test
    public void testMessageListenerRemoval() {
        // Test removing a listener
        SimpleCustomer tempCustomer = new SimpleCustomer("tempCustomer", QUEUE_NAME);
        
        // Remove the listener
        messageCenter.removeListener(QUEUE_NAME, tempCustomer.getListenerId());

        // After removing the listener, producer sends a message
        producer.run();

        // Ensure that no messages are received by the removed listener
        List<ImprovedMessage> tempReceivedMessages = tempCustomer.getMessages();
        assertTrue(tempReceivedMessages.isEmpty(), 
            "The removed listener should not receive any messages.");
    }
}
