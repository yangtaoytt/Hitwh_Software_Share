package cn.hitwh.yt.interfaces;

import java.util.Optional;

public interface ImprovedMessageBuffer {
    Optional<ImprovedMessage> getMsg();
}
