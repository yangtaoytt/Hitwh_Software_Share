package cn.hitwh.yt.implement;

import cn.hitwh.yt.factory.ImprovedMessageFactory;
import cn.hitwh.yt.interfaces.ImprovedMessage;
import cn.hitwh.yt.interfaces.ImprovedMessageBuffer;
import cn.hitwh.yt.interfaces.ImprovedMessageQueue;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

public class ImprovedSimpleMsgQueue implements ImprovedMessageQueue {
    private static final int INITIAL_LISTENER_ID = 0;
    private AtomicInteger listenerIdCounter = new AtomicInteger(INITIAL_LISTENER_ID);


    // 使用 ConcurrentHashMap 和线程池减少资源浪费
    private Map<Integer, Consumer<ImprovedMessageBuffer>> consumers = new ConcurrentHashMap<>();
    private ExecutorService executor = Executors.newFixedThreadPool(10); // 使用固定大小的线程池

    @Override
    public void enqueue(ImprovedMessage message) {
        if (message == null) {
            return;
        }
        // 创建消费者的快照，避免遍历期间修改
        List<Consumer<ImprovedMessageBuffer>> consumersSnapshot = new ArrayList<>(consumers.values());
        for (Consumer<ImprovedMessageBuffer> consumer : consumersSnapshot) {
            executor.submit(() -> consumer.accept(ImprovedMessageFactory.createMsgBuffer(List.of(message))));
        }
    }


    @Override
    public int addListener(Consumer<ImprovedMessageBuffer> callback) {
        if (callback == null) {
            throw new IllegalArgumentException("callback cannot be null");
        }
        int listenerId = listenerIdCounter.getAndIncrement();
        consumers.put(listenerId, callback);
        return listenerId;
    }

    @Override
    public void removeListener(int hash) {
        consumers.remove(hash);  // 直接删除
    }
}