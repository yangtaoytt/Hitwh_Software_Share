package cn.hitwh.yt;


import cn.hitwh.yt.factory.ImprovedMessageFactory;
import cn.hitwh.yt.implement.ImprovedSimpleMsgCenter;
import cn.hitwh.yt.interfaces.ImprovedMessage;
import cn.hitwh.yt.interfaces.ImprovedMessageCenter;

public class SimpleProducer implements Runnable{
    private final  String producerName;
    private final String msgQueueName;

    public SimpleProducer(String producerName, String msgQueueName) {
        this.producerName = producerName;
        this.msgQueueName = msgQueueName;
    }


    @Override
    public void run() {
        for(int i = 0 ; i < 10; i++) {
            ImprovedMessage msg = ImprovedMessageFactory.createMsg(ImprovedMessageFactory.MessageType.intMessage, i);
            ImprovedSimpleMsgCenter.getInstance().sendMessage(msgQueueName, msg);
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
