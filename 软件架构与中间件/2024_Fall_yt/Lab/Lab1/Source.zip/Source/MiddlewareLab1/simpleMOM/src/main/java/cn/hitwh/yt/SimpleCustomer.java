package cn.hitwh.yt;

import cn.hitwh.yt.implement.ImprovedSimpleMsgCenter;
import cn.hitwh.yt.interfaces.ImprovedMessage;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class SimpleCustomer {
    private final String customerName;
    private final String msgQueueName;
    private final List<ImprovedMessage> messages = new CopyOnWriteArrayList<>();

    private int hashId;
    public List<ImprovedMessage> getMessages() {
        return messages;
    }


    public SimpleCustomer(String customerName, String msgQueueName) {
        this.customerName = customerName;
        this.msgQueueName = msgQueueName;
        hashId = ImprovedSimpleMsgCenter.getInstance().addListener(msgQueueName, improvedMessageBuffer -> {
            ImprovedMessage msg = improvedMessageBuffer.getMsg().get();
            if (msg != null) {
                messages.add(msg);
            }
        });
    }

    public int getListenerId() {
        return hashId;
    }
}
